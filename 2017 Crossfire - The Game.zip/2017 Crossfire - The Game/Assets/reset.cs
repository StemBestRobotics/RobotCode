﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class reset : MonoBehaviour {
    private Vector3 pos;
    private Quaternion rot;
	// Use this for initialization
	void Start () {
        pos = this.transform.position;
        rot = this.transform.rotation;
	}
	
	// Update is called once per frame
	void Update () {
        if (Input.GetKeyDown(KeyCode.R))
        {
            this.transform.position = pos;
            this.transform.rotation = rot;
        }
	}
}
