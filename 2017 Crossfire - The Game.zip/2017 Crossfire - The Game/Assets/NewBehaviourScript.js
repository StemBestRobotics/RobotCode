#pragma strict
public var moveSpeed : float = 100f;
public var turnSpeed : float = 50f;
public var rocketPrefab : Rigidbody;
public var barrelEnd : Transform;
public var rotPoint : Transform;
var rocketInstance : Rigidbody;
var lastShot : float = 10;
function Update ()
{
    if(Input.GetKey(KeyCode.UpArrow))
        transform.Translate(Vector3.forward * moveSpeed * Time.deltaTime);
    
    if(Input.GetKey(KeyCode.DownArrow))
        transform.Translate(-Vector3.forward * moveSpeed * Time.deltaTime);
    
    if(Input.GetKey(KeyCode.LeftArrow))
        transform.RotateAround(rotPoint.position, Vector3.up, -turnSpeed * Time.deltaTime);
    
    if(Input.GetKey(KeyCode.RightArrow))
        transform.RotateAround(rotPoint.position, Vector3.up, turnSpeed * Time.deltaTime);
	
	if(Input.GetKeyDown(KeyCode.RightControl)){
        rocketInstance = Instantiate(rocketPrefab, barrelEnd.position, barrelEnd.rotation);
        rocketInstance.AddForce(barrelEnd.forward * Random.Range(3500,5000));
		rocketInstance.AddForce(barrelEnd.up * Random.Range(1500,3500));
		rocketInstance.AddForce(barrelEnd.right * Random.Range(-1000,1000));
	}
	if(Input.GetKey(KeyCode.W))
    transform.Translate(Vector3.forward * moveSpeed * Time.deltaTime);
    
    if(Input.GetKey(KeyCode.S))
        transform.Translate(-Vector3.forward * moveSpeed * Time.deltaTime);
    
    if(Input.GetKey(KeyCode.A))
        transform.RotateAround(rotPoint.position, Vector3.up, -turnSpeed * Time.deltaTime);
    
    if(Input.GetKey(KeyCode.D))
        transform.RotateAround(rotPoint.position, Vector3.up, turnSpeed * Time.deltaTime);
	
	if(Input.GetKeyDown(KeyCode.Space)){
        rocketInstance = Instantiate(rocketPrefab, barrelEnd.position, barrelEnd.rotation);
        rocketInstance.AddForce(barrelEnd.forward * Random.Range(3500,5000));
		rocketInstance.AddForce(barrelEnd.up * Random.Range(1500,3500));
		rocketInstance.AddForce(barrelEnd.right * Random.Range(-1500,1500));
	}
	if(Input.GetAxis("YL") > 0)
    transform.Translate(-Vector3.forward * moveSpeed * Time.deltaTime);
    
    if(Input.GetAxis("YL") < 0)
        transform.Translate(Vector3.forward * moveSpeed * Time.deltaTime);
    
    if(Input.GetAxis("XL") > 0)
        transform.RotateAround(rotPoint.position, Vector3.up, turnSpeed * Time.deltaTime);
    
    if(Input.GetAxis("XL") < 0)
        transform.RotateAround(rotPoint.position, Vector3.up, -turnSpeed * Time.deltaTime);
	
	if((Input.GetAxis("shootJoy") == 1) && ((Time.time - lastShot) > 10)){
        rocketInstance = Instantiate(rocketPrefab, barrelEnd.position, barrelEnd.rotation);
        rocketInstance.AddForce(barrelEnd.forward * Random.Range(3500,5000));
		rocketInstance.AddForce(barrelEnd.up * Random.Range(1500,3500));
		rocketInstance.AddForce(barrelEnd.right * Random.Range(-1500,1500));
		lastShot = Time.time;
	}
}