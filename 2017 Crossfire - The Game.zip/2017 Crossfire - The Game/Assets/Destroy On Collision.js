﻿#pragma strict

function OnCollisionEnter (col : Collision)
{
if(col.gameObject.name == "Cube (3)" || col.gameObject.name == "Base")
    {
        Destroy(gameObject);
    }
}