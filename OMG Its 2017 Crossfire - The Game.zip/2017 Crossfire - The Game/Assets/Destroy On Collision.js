﻿#pragma strict

function OnCollisionEnter (col : Collision)
{
if(col.gameObject.name == "CollideCheck" || col.gameObject.name == "Base" )
    {
        Destroy(gameObject);
    }
}