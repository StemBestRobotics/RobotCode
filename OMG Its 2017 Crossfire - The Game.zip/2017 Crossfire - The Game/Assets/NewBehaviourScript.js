#pragma strict
public var moveSpeed : float = 100f;
public var turnSpeed : float = 50f;
public var rocketPrefab : Rigidbody;
public var barrelEnd : Transform;
function Update ()
{
    if(Input.GetKey(KeyCode.UpArrow))
        transform.Translate(Vector3.forward * moveSpeed * Time.deltaTime);
    
    if(Input.GetKey(KeyCode.DownArrow))
        transform.Translate(-Vector3.forward * moveSpeed * Time.deltaTime);
    
    if(Input.GetKey(KeyCode.LeftArrow))
        transform.Rotate(Vector3.up, -turnSpeed * Time.deltaTime);
    
    if(Input.GetKey(KeyCode.RightArrow))
        transform.Rotate(Vector3.up, turnSpeed * Time.deltaTime);
	
	if(Input.GetKeyDown(KeyCode.RightControl)){
        var rocketInstance : Rigidbody;
        rocketInstance = Instantiate(rocketPrefab, barrelEnd.position, barrelEnd.rotation);
        rocketInstance.AddForce(barrelEnd.forward * Random.Range(350,500));
		rocketInstance.AddForce(barrelEnd.up * Random.Range(100,350));
	}
}